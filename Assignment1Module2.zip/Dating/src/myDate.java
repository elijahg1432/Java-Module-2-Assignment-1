//created by Elijah Gonzalez. Started Aug 27th, Finished Aug 28th. program grabs current
//date, as well as calculates how long its been since January 1st, 1970, in milliseconds

//import necessary components
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.Instant;

//this class obtains the current date, as well as taking time in ms and tells you what the date would be
public class myDate {

	//initialize variables
    private int day;
    private int month;
    private int year;
	
	//get the current date, and set it to day month and year. we must -1 from month, as month is supposed to be 0-based
	//this is a cunstructor with no arguements
	public myDate() {
		LocalDate currentDate = LocalDate.now();
		day = currentDate.getDayOfMonth();
		month = currentDate.getMonthValue() - 1;
		year = currentDate.getYear(); 
	}
	
	//gets the date from how many milliseconds it has been, starting from jan 1 1970, and sets it to day, month, and year.
	//this is a consturctor with only one arguement, being long, and then the milliseconds inputted
	public myDate(long milliseconds) {
		LocalDate date = Instant.ofEpochMilli(milliseconds).atZone(ZoneId.systemDefault()).toLocalDate();
		day = date.getDayOfMonth();
        month = date.getMonthValue() - 1;
        year = date.getYear();
	}
	
	//allows creation of myDate object using provided year, month, and day
	//this is a constructor with three arguements, being the int variables year, month, and day
	public myDate(int year, int month, int day) {
		this.day = day;
		this.month = month;
		this.year = year;
    }

	//getter methods that return day, month, and year. it "gets" the value of the attribute and "sets" it to the corresponding variables
	public int getDay() {
		return day;
	}

	public int getMonth() {
		return month;
	}

	public int getYear() {
		return year;
	}

	//you then convert the milliseconds to LocalDate, then update the variables to match how many milliseconds its been since Jan 1 1970
	public void setDate(long elapsedTime) {
		LocalDate date = Instant.ofEpochMilli(elapsedTime).atZone(ZoneId.systemDefault()).toLocalDate();
		this.day = date.getDayOfMonth();
        this.month = date.getMonthValue() - 1;
        this.year = date.getYear();	
	}
 }


