//created by Elijah Gonzalez, made and finished on Aug 28th, 2024

class displayMyDate {
    public static void main(String[] args) {
        
        //using myDate using the consctuctor with no args. it prints the current date. on the month segment, we add one, because month is 0 based. if jan is 0, we must add one to have it be jan is 1.
        myDate date1 = new myDate();
        System.out.println("Current Date:");
        System.out.println("Year: " + date1.getYear());
        System.out.println("Month: " + (date1.getMonth() + 1)); 
        System.out.println("Day: " + date1.getDay());

        System.out.println(" ");

        //we use the myDate constuctor with one arg, being the long. that is how we get the year date and day from jan 1st 1970, if its been, hypothetically, 34355555133101 milliseconds since then. we add 1 to month
        //again here.
        long elapsedTime = 34355555133101L;
        myDate date2 = new myDate(elapsedTime);
        System.out.println("Date from " + elapsedTime + " milliseconds since January 1, 1970:");
        System.out.println("Year: " + date2.getYear());
        System.out.println("Month: " + (date2.getMonth()+1));  
        System.out.println("Day: " + date2.getDay());
    }
}
